#!/usr/bin/env python3
"""
stress_test30.py — 第三十轮：T=3276800 单种子极限 + 全局汇总

stress_test29 最优：
  T=1638400 (1 seed): avg=+0.6564, std=+0.5693, trans=+0.7434, p2p=+0.4235

T-scaling 总结 (cascade7+Kalman+LPF):
  T=6400    (5 seeds): avg=+0.4509, std=+0.4216, trans=+0.4802, p2p=+0.1107
  T=12800   (3 seeds): avg=+0.4516, std=+0.4202, trans=+0.4830, p2p=+0.2261
  T=25600   (2 seeds): avg=+0.5277, std=+0.4809, trans=+0.5746, p2p=+0.2120  ★ jump
  T=51200   (3 seeds): avg=+0.5880, std=+0.5218, trans=+0.6542, p2p=+0.2081
  T=102400  (2 seeds): avg=+0.6333, std=+0.5529, trans=+0.7138, p2p=+0.2105
  T=204800  (2 seeds): avg=+0.6503, std=+0.5797, trans=+0.7208, p2p=+0.1293
  T=409600  (1 seed):  avg=+0.6376, std=+0.5606, trans=+0.7146, p2p=+0.4433
  T=819200  (1 seed):  avg=+0.6498, std=+0.5663, trans=+0.7332, p2p=+0.4433
  T=1638400 (1 seed):  avg=+0.6564, std=+0.5693, trans=+0.7434, p2p=+0.4235

本轮：
  1. T=3276800 单种子极限
  2. 输出全局 T-scaling 对比表
"""
import sys, os, numpy as np, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from metrics.coherence_index import compute_coherence, central_diff
from legged_env import BasePolicy, LeggedMicroSim
from plugins import BasePlugin
from plugins_v8 import GoldilocksFusion

SEEDS_1 = [42]


def opt(ci_p, ci_b): return (ci_p - ci_b) / (1 - ci_b + 1e-9)


def eval_plugin(make_fn, family, seeds, T=800):
    opts = []
    for seed in seeds:
        base = BasePolicy(n_joints=6, family=family, seed=seed)
        sim_b = LeggedMicroSim(base, plugins=[], seed=seed, T=T)
        t = sim_b.run(goal=3.0, terrain=0.3)
        ci_b = compute_coherence(t['q'], t['dq'],
                                 central_diff(t['dq'], sim_b.dt),
                                 dt=sim_b.dt)['coherence_index']
        plug = make_fn()
        sim_p = LeggedMicroSim(base, plugins=[plug], seed=seed, T=T)
        t2 = sim_p.run(goal=3.0, terrain=0.3)
        ci_p = compute_coherence(t2['q'], t2['dq'],
                                 central_diff(t2['dq'], sim_p.dt),
                                 dt=sim_p.dt)['coherence_index']
        opts.append(opt(ci_p, ci_b))
    return float(np.mean(opts)), float(np.std(opts))


def run_round(round_num, name, make_fn, T=800, seeds=SEEDS_1, all_r=None, out_path=None):
    results = {}
    for fam in ['p2p', 'standard', 'transformer']:
        m, s = eval_plugin(make_fn, fam, seeds, T=T)
        results[fam] = {'mean': m, 'std': s}
    uni = all(results[f]['mean'] > 0 for f in ['p2p', 'standard', 'transformer'])
    results['universal'] = uni
    tag = "OK" if uni else "--"
    avg = (results['standard']['mean'] + results['transformer']['mean']) / 2
    print(f"  R{round_num}: {name:50s}  std={results['standard']['mean']:+.4f}  trans={results['transformer']['mean']:+.4f}  avg={avg:+.4f}  p2p={results['p2p']['mean']:+.4f}  {tag}", flush=True)
    if all_r is not None:
        all_r[f'R{round_num}_{name.replace(" ", "_").replace("=", "")}'] = results
        if out_path:
            with open(out_path, "w") as f:
                json.dump(all_r, f, ensure_ascii=False, indent=2)
    return results


class AdaptiveLPF(BasePlugin):
    def __init__(self, decay=0.3, strength=0.8,
                 j_act_lo=0.3, j_act_hi=1.0):
        self.decay = decay
        self.strength = strength
        self.j_act_lo = j_act_lo
        self.j_act_hi = j_act_hi
        self._hist = []
        self._jerk_hist = []
        self._last_a = None

    def _measure_jerk(self, a):
        if self._last_a is None:
            self._last_a = a.copy()
            return 0.0
        j = float(np.linalg.norm(a - self._last_a))
        self._last_a = a.copy()
        self._jerk_hist.append(j)
        if len(self._jerk_hist) > 20:
            self._jerk_hist.pop(0)
        if len(self._jerk_hist) < 3:
            return 0.0
        return float(np.mean(self._jerk_hist))

    def _adaptive_gate(self, j):
        if j < self.j_act_lo:
            return 0.0
        if j >= self.j_act_hi:
            return 1.0
        t = (j - self.j_act_lo) / (self.j_act_hi - self.j_act_lo + 1e-9)
        return float(t)

    def inject(self, a, **kw):
        a = np.asarray(a, dtype=float)
        self._hist.append(a.copy())
        if len(self._hist) > 5:
            self._hist.pop(0)
        if len(self._hist) < 2:
            return a
        j = self._measure_jerk(a)
        gate = self._adaptive_gate(j)
        if gate < 0.01:
            return a
        weights = np.array([(1 - self.decay) ** i for i in range(len(self._hist) - 1, -1, -1)])
        weights = weights / weights.sum()
        smoothed = np.average(np.stack(self._hist), axis=0, weights=weights)
        return a + self.strength * gate * (smoothed - a)


class KalmanSmoother(BasePlugin):
    def __init__(self, process_var=0.01, meas_var=0.05, strength=0.7,
                 j_lo=0.05, j_peak=0.15, j_hi=0.5):
        self.process_var = process_var
        self.meas_var = meas_var
        self.strength = strength
        self.j_lo, self.j_peak, self.j_hi = j_lo, j_peak, j_hi
        self._x_hat = None
        self._p = None
        self._jerk_hist = []
        self._last_a = None

    def inject(self, a, **kw):
        a = np.asarray(a, dtype=float)
        if self._x_hat is None:
            self._x_hat = a.copy()
            self._p = np.ones_like(a) * self.meas_var
            return a
        if self._last_a is None:
            self._last_a = a.copy()
            self._jerk_hist.append(0.0)
        else:
            j = float(np.linalg.norm(a - self._last_a))
            self._last_a = a.copy()
            self._jerk_hist.append(j)
            if len(self._jerk_hist) > 20:
                self._jerk_hist.pop(0)
        j_val = float(np.mean(self._jerk_hist[-3:])) if len(self._jerk_hist) >= 3 else 0.0

        self._p = self._p + self.process_var
        K = self._p / (self._p + self.meas_var)
        self._x_hat = self._x_hat + K * (a - self._x_hat)
        self._p = (1 - K) * self._p

        if j_val < self.j_lo or j_val > self.j_hi:
            gate = 0.0
        elif j_val <= self.j_peak:
            t = (j_val - self.j_lo) / (self.j_peak - self.j_lo + 1e-9)
            gate = float(np.sin(t * np.pi / 2))
        else:
            t = (j_val - self.j_peak) / (self.j_hi - self.j_peak + 1e-9)
            gate = float(np.cos(t * np.pi / 2))

        if gate < 0.01:
            return a
        return a + self.strength * gate * (self._x_hat - a)


class BestCombo(BasePlugin):
    def __init__(self, n_cascade=7, kalman_s=0.7,
                 lpf_decay=0.3, lpf_strength=0.8,
                 j_peak=0.15, j_hi=0.5,
                 j_act_lo=0.3, j_act_hi=1.0):
        wide = {'lam': 1.0, 'alpha': 1.0, 'j_peak': j_peak, 'j_hi': j_hi}
        self.cascade = [GoldilocksFusion(**wide) for _ in range(n_cascade)]
        self.kalman = KalmanSmoother(strength=kalman_s)
        self.lpf = AdaptiveLPF(decay=lpf_decay, strength=lpf_strength,
                                j_act_lo=j_act_lo, j_act_hi=j_act_hi)

    def inject(self, a, **kw):
        for p in self.cascade:
            a = p.inject(a, **kw)
        a = self.kalman.inject(a, **kw)
        return self.lpf.inject(a, **kw)


def main():
    out = os.path.join(os.path.dirname(__file__), "stress_test30.json")
    print("=" * 120)
    print("第三十轮：T=3276800 单种子极限 (cascade7+K+LPF) + 全局汇总")
    print("=" * 120, flush=True)
    all_r = {}

    run_round(0, "cascade7+K+LPF T=3276800", lambda: BestCombo(n_cascade=7),
              T=3276800, seeds=SEEDS_1, all_r=all_r, out_path=out)

    # 全局汇总
    print(f"\n{'='*120}")
    print("本次 + 全局 T-scaling 汇总表 (cascade7+Kalman+LPF)")
    print(f"{'='*120}")
    T_historical = [
        (6400,    5, "+0.4509", "+0.4216", "+0.4802", "+0.1107", "stress_test22/23"),
        (12800,   3, "+0.4516", "+0.4202", "+0.4830", "+0.2261", "stress_test22"),
        (25600,   2, "+0.5277", "+0.4809", "+0.5746", "+0.2120", "stress_test27"),
        (51200,   3, "+0.5880", "+0.5218", "+0.6542", "+0.2081", "stress_test24"),
        (102400,  2, "+0.6333", "+0.5529", "+0.7138", "+0.2105", "stress_test25"),
        (204800,  2, "+0.6503", "+0.5797", "+0.7208", "+0.1293", "stress_test26"),
        (409600,  1, "+0.6376", "+0.5606", "+0.7146", "+0.4433", "stress_test27"),
        (819200,  1, "+0.6498", "+0.5663", "+0.7332", "+0.4433", "stress_test28"),
        (1638400, 1, "+0.6564", "+0.5693", "+0.7434", "+0.4235", "stress_test29"),
    ]
    print(f"  {'T':>8s}  {'seeds':>5s}  {'avg':>8s}  {'std':>8s}  {'trans':>8s}  {'p2p':>8s}  source")
    print("  " + "-" * 85)
    for t, s, a, st, tr, p, src in T_historical:
        print(f"  {t:>8d}  {s:>5d}  {a:>8s}  {st:>8s}  {tr:>8s}  {p:>8s}  {src}")

    # 本次结果
    print(f"\n本次结果:")
    sorted_r = sorted(all_r.items(),
                      key=lambda x: (x[1]['standard']['mean'] + x[1]['transformer']['mean']) / 2,
                      reverse=True)
    print(f"  {'配置':42s}  {'std':>8s}  {'trans':>8s}  {'avg':>8s}  {'p2p':>8s}  通用?")
    print("  " + "-" * 90)
    for k, v in sorted_r:
        uni = v.get('universal', False)
        avg = (v['standard']['mean'] + v['transformer']['mean']) / 2
        print(f"  {k:42s}  {v['standard']['mean']:+.4f}  {v['transformer']['mean']:+.4f}  {avg:+.4f}  {v['p2p']['mean']:+.4f}  {'YES' if uni else 'NO'}")

    best = sorted_r[0]
    print(f"\n  本次最优: {best[0]} → avg={(best[1]['standard']['mean']+best[1]['transformer']['mean'])/2:+.4f}")
    print(f"  历史最优: T=1638400 → avg=+0.6564 (+65.64%)")
    print(f"  结果已写入 {out}")


if __name__ == "__main__":
    main()
