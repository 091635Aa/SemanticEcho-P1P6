# 验证方案 + 外挂方案：能否套入宇树（Unitree）真机

> 日期：2026-08-26
> 前置结论：TPIP 在合成微仿真已达 avg=+65.88%，但第 33 轮多种子验证裁决"合成 CI 指标下外挂不再提升 avg"。
> 本文回答：**基于宇树真实部署栈接口，外挂/验证方案能否、以及如何套入真机。**

---

## 一、判定速览

| 问题 | 判定 |
|---|---|
| 外挂在宇树真机上有没有干净插入点？ | ✅ **有**：`policy 输出 → PD 之前` |
| 是否满足"零权重、不改策略、纯旁路"约束？ | ✅ **是**（只改官方 deploy C++ 例程、不加到策略权重） |
| 外挂运行频率与实时性可否满足？ | ✅ 挂 50Hz 软件循环，**不碰 1kHz 实时 MCU** |
| 真机收益能否由现有合成实验背书？ | ❌ **不能**，必须真机/物理仿真 + 真实物理量重新标定 |
| 有无过度平滑/失稳风险？ | ⚠️ 有（时序推演已见"平滑吞信息"），必须带安全总开关 |

---

## 二、宇树真实部署栈接口坐标（实证）

| 层 | 内容 | 频率 | 位置/接口 |
|---|---|---|---|
| 策略推理 | `policy.onnx`（ONNX Runtime） | **50 Hz** | 官方 `deploy/robots/<型号>/build/*_ctrl`（C++）；配置文件 `config.yaml`（FSM） |
| 输出 | **关节目标位置** `a ∈ ℝ^DOF` | 50 Hz | policy 前向结果（G1=29DOF, Go2=12DOF） |
| 底层跟踪 | PD 伺服（`kp,kd`） | **1 kHz** | MCU；config.yaml `kp/kd` 数组按 DOF |
| 通信 | unitree_sdk2(CycloneDDS) / ROS2 | ms 级 | 静态 IP `192.168.123.x`；onboard/网线 |
| 仿真侧 | Isaac Lab（正式）/ MuJoCo（官方侧） | Git2Real 直迁（SONIC 100%） | Isaac Lab：`isaac-rl-quad-humanoid` 等 |

**关键含义**：宇树是"**策略出关节目标 → PD 跟踪**"的两级结构。策略步进只在 50Hz，PD 在 1kHz 实时 MCU。因此**只需在 50Hz 的 policy 输出与 PD 前一步之间插一段旁路处理**，完全不接触实时 MCU，这就是外挂的天然挂载点。

---

## 三、外挂插入点架构

```
unitree *_ctrl (50 Hz 循环)
  obs ──→ policy.onnx ──→ a(关节目标) ──┐
                                         │  ★ TPIP 外挂旁路（50Hz，纯软件）
         a' = TPIP(a, hist, 周期, flag) ─┘
                                         ↓
                                   写 PD 目标 (1kHz 驱动)
```

- **不改** `policy.onnx`、**不加**任何训练/权重；
- 在官方开源 `deploy/robots/<xm>/deploy` 的 C++ 循环里，`policy 返回 a 之后、下发 PD 之前`嵌入 `tpip_inject(float* a, const State& s)`。

### 外挂管线（C++ 建议实现）

```
TPIP_State {
  CircularBuff history[W];        // 近 W 步关节目标（W≈2×周期）
  float est_period;               // 在线步态周期（零交叉/DFT 估计，已验证收敛）
  float gain;                     // 全局幅度门控（默认 1.0，故障即时置 0）
  bool bypass;                    // 总开关，bypass=true 时 a'=a
}
a' = LPF( Kalman( CascadeGoldilocks(a, j_k, gate) ) );   // 合成 BestCombo，移植未改
    期间用 在线周期 选 块长/时间常数；gate 由 jerk 门控；gain 缩放到安全幅度
```

工程要点（相对合成必须改的 4 处）：
1. **频率**：策略 50Hz → dt=0.02s；在线周期估计出的步长为"步/周期"，时间常数随之换算（1Hz 步态=50 步）。
2. **延迟补偿**：真机有观测 + SDK + PD 延迟；外挂历史平滑会加滞后，需保留小相位超前项（对应方案第 5 级），其量值须真机实测后标定（不可照搬合成）。
3. **安全**：`bypass` 与 `gain` 都接 FSM 状态（允许 `Velocity`，悬空/故障时置 bypass=1）；平滑强度上限由"扰动响应不能退化"约束。
4. **可测目标**：从合成 CI 换成**真实物理量**（见第五节）——这是"能否优化"的唯一判据。

---

## 四、验证方案（真机前分四阶段）

| 阶段 | 平台 | 验证内容 | 判定门槛 |
|---|---|---|---|
| P1 单元 | MuJoCo（官方 simulate 侧，`--network=lo` 联调） | 外挂不越界、bypass 可靠、50Hz 实时性 | 无越界/无 ABI 崩溃、RTT<5ms @50Hz |
| P2 物理仿真 | Isaac Lab（Go2 12D / G1 29D 已有环境） | 开/关外挂对照，**真实物理指标** | 见指标表，需 ≥3 tilt/seeds 稳健 |
| P3 稳定性 | Isaac Lab 加扰动/越障/弹跳 | 外挂不劣化扰动响应、不失稳 | 最大稳定扰动不下降 |
| P4 真机 | 吊装 → 平地面 → 走跑 | 平滑收益实感 + 安全旁路 | P2 最优参数冻结后复测 |

### 真机/物理仿真标定指标（替换合成 CI）

| 指标 | 含义 | 外挂目标 |
|---|---|---|
| 关节 jerk（Σ‖q̇‖ 高阶导） | 抖振 | ↓ |
| 能耗 τ·θ̇ 积分 | 功耗 | ↓ |
| 触地反力震荡 (GRF 高频峰) | 落地冲击 | ↓ |
| 站立扰动后回稳时间 | 鲁棒性 | 不劣化 |
| 速度/高度跟踪误差 | 任务保真 | 不劣化 |

**判定**：仅当 抖动/能耗/冲击 下降 且 跟踪误差+鲁棒 不退化 时，才认定真机"能优化"。

---

## 五、理论推演（能否套入的机理判断）

1. **真机痛点匹配**：宇树 RL 策略在 50Hz 输出关节目标、PD 1kHz 跟踪，高频段天然有目标抖振（量化/策略噪声）。TPIP 的平滑+门控正是压这一频段——**比合成基座更贴近"平滑能起作用"的场景**，因此真机上有合成上不存在的潜在收益空间。
2. **收益不再被"合成 CI 种子噪声"淹没**：第 33 轮 avg 零增益的根因是合成指标对 0.3Hz 慢漂移的 P_coinc 判定掩盖了微抖。真机用**物理抖振/能耗**衡量时，平滑的收益可被直接测量，不再被相位重合度噪声淹没。
3. **最大风险仍在平滑过度**：时序里多次出现"平滑吞掉信息→鲁棒/相位崩"。真机上表现为扰动响应迟钝、易失稳。故 `gain` 上限 + `bypass` 是必需件，先小后大扫 gain。

**结论：可套入（方法学成立、插入点明确），但收益必须由 P2–P4 的真机/物理指标实测裁决，现有合成实验不构成背书。**

---

## 六、局限与诚实声明

- 本方案基于官方 deploy/unitree_sdk2 开源接口推断；实际 `*_ctrl` 内部字段、PD 下发调用点需在仓库内确认后微调。
- 合成微仿真产不出真机物理收益数字；+65.88% 仅证明"TPIP 平滑机制在动作层有效、可迁移"，**不是**真机可达到的数值。
- 未持有宇树真机/Isaac GPU 环境，P1–P4 需在你的硬件/账号下执行；本文提供的是**路线图与判定门槛**。

---

## 七、开源可得性核实（联网实证，2026-08）

理论挂入点配合**全部开源依赖**后，判定升级为"可复现、可自行闭环验证"。逐一核实如下（均真实存在于公开仓库/活跃维护）：

| 依赖 | 仓库/资源 | 许可 | 活跃度 | 用途 |
|---|---|---|---|---|
| 底层 SDK | [unitree_sdk2](https://github.com/unitreerobotics/unitree_sdk2) | **BSD-3-Clause** | 169 commits / 最近 2026-08 更新 | 外挂的通信层（DDS 下发 PD 目标） |
| RL 训练 | [unitree_rl_lab](https://github.com/unitreerobotics/unitree_rl_lab) | 开源 | 700+ stars，IsaacLab 2.3.0 / 2025-11 | Go2/H1/G1 策略 + **deploy/** C++ 控制例程 |
| 训练+部署 | [unitree_rl_gym](https://github.com/unitreerobotics/unitree_rl_gym) | **BSD-3-Clause** | 2.8k stars，含 **deploy/** | Isaac Gym→MuJoCo sim2sim + 真机例程 |
| 物理仿真(side) | [unitree_mujoco](https://github.com/unitreerobotics/unitree_mujoco) | 开源 | 805 stars | P1/P2 廉价验证，sim2real 无缝 |
| **理想验证台** | [unitree_sim_isaaclab](https://github.com/unitreerobotics/unitree_sim_isaaclab) | 开源 | H1_2/G1 | 高保真 + **DDS 同真机**，外挂可无差别复用 |
| 模型/SDK | [unitree_model / sdk2_python](https://github.com/unitreerobotics/) | 开源 | URDF/MJCF；Python SDK | 几何/惯量；脚本侧联调 |
| 第三方可参考 | [go2_isaaclab_deploy](https://github.com/syw-robotics/go2_isaaclab_deploy) · [unitree_cpp_deploy](https://github.com/wty-yy/unitree_cpp_deploy) | Apache-2.0 | C++ `go2_ctrl` + ONNX Runtime + FSM | 直接给出外挂插入点的成品循环 |

**确认的关键落点**：无论官方 `unitree_rl_lab/deploy/robots/go2/*_ctrl`、还是第三方 `go2_ctrl`，都是同一个结构——`读 obs → policy.onnx 前向 → 得关节目标 a → unitree_sdk2 写 PD`。外挂 `tpip_inject(&a, state)` 就插在**前向结果之后、sdk2 下发之前**这一行，任何一份开源 ctrl 都能改，且规约完全相同。

**结论升级**：外挂套入宇树，**理论成立 + 开源可复现 + 许可证宽松（BSD/Apache）**，可完全在开源软件栈内自闭环验证（训练→离线下→加外挂→P1-MuJoCo→P2-IsaacLab/unitree_sim_isaaclab→真机）。唯一留给真机/物理量的是"收益数值"裁决，而不再是"能否接入"。

---

## 八、交付到位

方案与验证请以本文件为准；合成侧代码/数据见 `stress_*`、`verify_architecture.*`、`unitree_ai_model_transfer_plan.md`。克隆仓库后对照 P1–P4 执行。